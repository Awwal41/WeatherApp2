package bgtap.babbangona.weatherapp2.models

import java.io.Serializable

data class Clouds(
    val all: Int
) : Serializable